#ifndef _NGX_HTTP_VOD_DASH_H_INCLUDED_
#define _NGX_HTTP_VOD_DASH_H_INCLUDED_

// includes
#include "ngx_http_vod_submodule.h"

// globals
extern const ngx_http_vod_submodule_t dash;

#endif // _NGX_HTTP_VOD_DASH_H_INCLUDED_
